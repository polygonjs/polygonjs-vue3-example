import{a as c}from"./chunk-HES3Q7MP.js";import"./chunk-4NZTGWFT.js";var r=async function(e={}){return e&&e.createViewer==null&&(e.createViewer=!0),c(e)};export{r as loadSceneAndMountAsync_scene_01};
