import{W as e}from"../chunk-FVLBNX7V.js";import{dc as o}from"../chunk-WDUCRR75.js";import"../chunk-KBNISIIW.js";var r={moduleName:o.GLTFLoader,module:e};export{r as GLTFLoaderModule};
